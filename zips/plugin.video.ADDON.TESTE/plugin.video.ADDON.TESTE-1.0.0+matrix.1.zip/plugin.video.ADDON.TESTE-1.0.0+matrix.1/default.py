# -*- coding: utf-8 -*-
import sys
import urllib.parse
import xbmcaddon, xbmcgui, xbmcplugin

# ============================================================
# CONFIGURAÇÕES GERAIS DO ADDON
# Aqui você define tudo que é base do addon:
# URL principal do servidor, ID, handle, etc.
# ============================================================
URL_PRINCIPAL = "https://meu-servidor.com/api"
addon      = xbmcaddon.Addon()
addon_id   = addon.getAddonInfo("id")
handle     = int(sys.argv[1])



# ============================================================
# FUNÇÃO DE PARÂMETROS DO KODI
# Lê ?action=...&mode=...&url=...
# ============================================================
def get_params():
    p = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    return {
        "action": p.get("action"),
        "mode":   p.get("mode"),
        "url":    p.get("url")
    }



# ============================================================
# ROTEADOR PRINCIPAL
# Decide para onde o addon vai quando clicado.
# ============================================================
def router(params):
    action = params["action"]
    mode   = params["mode"]
    url    = params["url"]

    # Sem parâmetros → abre menu inicial
    if not action and not mode:
        return home()

    # Rotas ACTION
    if action == "play_torrent":
        return play_torrent(url)
    elif action == "remote_request":
        return remote_json(url)
    elif action == "remote_xml":
        return remote_xml(url)

    # Rotas MODE (segundo sistema)
    if mode == "listar":
        return listar_api(URL_PRINCIPAL)
    if mode == "play":
        return play_torrent(url)



# ============================================================
# MENU INICIAL DO ADDON
# Aqui você organiza suas opções principais.
# ============================================================
def home():
    add_item(
        "Torrent Exemplo",
        "magnet:?xt=urn:btih:EXEMPLO",
        action="play_torrent",
        icon="https://via.placeholder.com/200",
        fanart="https://via.placeholder.com/800"
    )

    add_item(
        "Lista JSON (ACTION)",
        URL_PRINCIPAL,
        action="remote_request"
    )

    add_item(
        "Lista JSON (MODE)",
        URL_PRINCIPAL,
        mode="listar"
    )

    add_item(
        "Listar XML Remoto",
        "https://meu-servidor.com/lista.xml",
        action="remote_xml"
    )

    xbmcplugin.endOfDirectory(handle)



# ============================================================
# FUNÇÃO UNIVERSAL PARA CRIAR UM ITEM NO KODI
# Aceita: título, url, action/mode, icon, fanart e descrição
# ============================================================
def add_item(name, url, action=None, mode=None, icon=None, fanart=None, plot=None):
    q = urllib.parse.quote_plus(url)

    # Construção da URL
    if action:
        u = f"{sys.argv[0]}?action={action}&url={q}"
    elif mode:
        u = f"{sys.argv[0]}?mode={mode}&url={q}"
    else:
        return

    li = xbmcgui.ListItem(label=name)

    # Artes visuais (icone, poster, fanart)
    if icon:
        li.setArt({
            "thumb": icon,
            "icon": icon,
            "poster": icon
        })
    if fanart:
        li.setArt({"fanart": fanart})

    # Informações extras (sinopse)
    if plot:
        li.setInfo("video", {"plot": plot})

    xbmcplugin.addDirectoryItem(handle, u, li, False)



# ============================================================
# PLAYER – ENVIA O MAGNET PRO ELEMENTUM
# ============================================================
def play_torrent(magnet):
    el_url = f"plugin://plugin.video.elementum/play?uri={magnet}"
    li = xbmcgui.ListItem(path=el_url)
    xbmcplugin.setResolvedUrl(handle, True, li)



# ============================================================
# LEITURA DE API / JSON REMOTO (ACTION)
# ============================================================
def remote_json(endpoint):
    import requests

    try:
        data = requests.get(endpoint, timeout=6).json()
    except Exception as e:
        xbmcgui.Dialog().notification("Erro API", str(e), xbmcgui.NOTIFICATION_ERROR)
        return

    for item in data.get("items", []):
        add_item(
            item["title"],
            item["magnet"],
            action="play_torrent",
            icon=item.get("thumb"),
            fanart=item.get("fanart"),
            plot=item.get("plot")
        )

    xbmcplugin.endOfDirectory(handle)



# ============================================================
# LEITURA DA API (MODE) – SEGUNDA OPÇÃO
# ============================================================
def listar_api(endpoint):
    import requests

    try:
        data = requests.get(endpoint, timeout=6).json()
    except:
        xbmcgui.Dialog().notification("API", "Servidor indisponível", xbmcgui.NOTIFICATION_ERROR)
        return

    for item in data.get("videos", []):
        add_item(
            item["titulo"],
            item["magnet"],
            mode="play",
            icon=item.get("thumb"),
            fanart=item.get("fanart"),
            plot=item.get("descricao")
        )

    xbmcplugin.endOfDirectory(handle)



# ============================================================
# LEITURA DE XML REMOTO
# Aceita XML padrão IPTV (item/title/link/thumbnail/fanart)
# ============================================================
def remote_xml(url):
    import requests
    import xml.etree.ElementTree as ET

    try:
        xml_raw = requests.get(url, timeout=6).text
        root = ET.fromstring(xml_raw)
    except Exception as e:
        xbmcgui.Dialog().notification("Erro XML", str(e), xbmcgui.NOTIFICATION_ERROR)
        return

    for item in root.findall("item"):
        title  = item.find("title").text
        link   = item.find("link").text
        icon   = item.find("thumbnail").text if item.find("thumbnail") is not None else None
        fanart = item.find("fanart").text if item.find("fanart") is not None else None

        add_item(title, link, action="play_torrent", icon=icon, fanart=fanart)

    xbmcplugin.endOfDirectory(handle)



# ============================================================
# EXECUÇÃO FINAL DO SCRIPT
# ============================================================
if __name__ == "__main__":
    params = get_params()
    router(params)