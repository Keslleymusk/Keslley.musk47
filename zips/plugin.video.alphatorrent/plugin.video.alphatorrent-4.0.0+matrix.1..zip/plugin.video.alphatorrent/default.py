# -*- coding: utf-8 -*-
#Desenvolvido por @keslley.musk47 – Torrent + Servidor Remoto + Favoritos + Debug (corrigido translatePath)

import sys
import json
import urllib.request
import xml.etree.ElementTree as ET
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import os

# tentativa de importar xbmcvfs para translatePath em ambientes modernos
try:
    import xbmcvfs
except Exception:
    xbmcvfs = None

def translate(path):
    """
    Translate special:// paths portably:
    - usa xbmcvfs.translatePath se disponível
    - senão tenta xbmc.translatePath (antigas builds)
    - senão retorna a string (Kodi resolverá internamente em muitos casos)
    """
    try:
        if xbmcvfs and hasattr(xbmcvfs, 'translatePath'):
            return xbmcvfs.translatePath(path)
    except Exception:
        pass
    try:
        if hasattr(xbmc, 'translatePath'):
            return xbmc.translatePath(path)
    except Exception:
        pass
    return path

addon       = xbmcaddon.Addon()
addon_name  = addon.getAddonInfo('name')
addon_icon  = addon.getAddonInfo('icon')
addon_handle = int(sys.argv[1]) if len(sys.argv) > 1 else 1

# URL remota (ajuste se necessário)
URL_PRINCIPAL = 'https://raw.githubusercontent.com/Keslleymusk/Keslley.musk47/main/README.md'

# FAVORITOS: caminho seguro, gravável
FAV_FILE = translate("special://home/alphatorrent_favorites.json")

# ----------------------
# DEBUG – exibe URL ao clicar
# ----------------------
def debug(msg):
    try:
        xbmcgui.Dialog().ok("DEBUG", str(msg))
    except Exception:
        xbmc.log("[alphatorrent][DEBUG] %s" % str(msg), xbmc.LOGNOTICE)

# ----------------------
# Favoritos
# ----------------------
def fav_load():
    try:
        if os.path.exists(FAV_FILE):
            with open(FAV_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        try:
            return json.load(open(FAV_FILE, "r"))
        except Exception:
            return []
    return []

def fav_save(data):
    try:
        with open(FAV_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except Exception:
        # fallback sem crash
        try:
            json.dump(data, open(FAV_FILE, "w"), indent=2)
        except Exception:
            xbmc.log("[alphatorrent] Falha ao salvar favoritos", xbmc.LOGERROR)

def fav_add(title, link, thumb, plot):
    favs = fav_load() or []
    item = {"title": title, "link": link, "thumb": thumb, "plot": plot}
    if item not in favs:
        favs.append(item)
        fav_save(favs)
        try:
            xbmcgui.Dialog().notification("Favoritos", "Adicionado!", addon_icon, 2000)
        except:
            pass

def fav_list():
    favs = fav_load() or []
    for it in favs:
        add_list_item(it.get("title","Sem título"), it.get("link",""), it.get("thumb",""), it.get("plot",""), is_favorite=False)
    xbmcplugin.endOfDirectory(addon_handle)

# ----------------------
# Requisição remota
# ----------------------
def get_request(url):
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        data = urllib.request.urlopen(req, timeout=15).read()
        try:
            return data.decode("utf-8")
        except:
            return data.decode("latin-1", errors="ignore")
    except Exception as e:
        xbmc.log(f"[alphatorrent] Erro get_request: {e}", xbmc.LOGERROR)
        try:
            xbmcgui.Dialog().notification("Erro", "Falha ao acessar servidor", addon_icon, 3000)
        except:
            pass
        return ""

# ----------------------
# Parser XML
# ----------------------
def parse_xml(text):
    items = []
    if not text:
        return items
    try:
        root = ET.fromstring(text)
        for it in root.findall(".//item"):
            title = (it.findtext("title") or it.findtext("name") or "").strip()
            link  = (it.findtext("link") or it.findtext("externallink") or "").strip()
            thumb = (it.findtext("thumbnail") or "").strip()
            plot  = (it.findtext("info") or it.findtext("description") or "").strip()
            if title and link:
                items.append({"title": title, "link": link, "thumb": thumb, "plot": plot})
    except Exception as e:
        xbmc.log(f"[alphatorrent] parse_xml falhou: {e}", xbmc.LOGWARNING)
    return items

# ----------------------
# Parser JSON
# ----------------------
def parse_json(text):
    items = []
    if not text:
        return items
    try:
        data = json.loads(text)
    except Exception:
        return items

    if isinstance(data, dict):
        data = data.get("items") or data.get("data") or data.get("list") or []

    if not isinstance(data, list):
        data = [data]

    for it in data:
        if not isinstance(it, dict):
            continue
        title = (it.get("title") or it.get("name") or "").strip()
        link  = (it.get("link") or it.get("magnet") or it.get("torrent") or "").strip()
        thumb = (it.get("thumbnail") or "").strip()
        plot  = (it.get("info") or it.get("description") or "").strip()
        if title and link:
            items.append({"title": title, "link": link, "thumb": thumb, "plot": plot})
    return items

# ----------------------
# Resolver feed
# ----------------------
def load_items():
    text = get_request(URL_PRINCIPAL)
    if not text:
        return []
    st = text.strip()
    if st.startswith("{") or st.startswith("["):
        items = parse_json(text)
        if items:
            return items
    return parse_xml(text)

# ----------------------
# Listagem
# ----------------------
def add_list_item(title, link, thumb, plot, is_favorite=True):
    li = xbmcgui.ListItem(label=title)
    try:
        li.setInfo("video", {"title": title, "plot": plot})
    except:
        pass
    if thumb:
        try:
            li.setArt({"thumb": thumb, "icon": thumb})
        except:
            pass

    url = f"{sys.argv[0]}?play={urllib_request_quote(link)}"
    menu = []
    if is_favorite:
        menu.append(("Adicionar aos Favoritos", f"RunPlugin({sys.argv[0]}?addfav={urllib_request_quote(link)}&title={urllib_request_quote(title)})"))
    menu.append(("DEBUG: Mostrar URL", f"RunPlugin({sys.argv[0]}?debug={urllib_request_quote(link)})"))
    try:
        li.addContextMenuItems(menu, replaceItems=False)
    except:
        pass

    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)

def urllib_request_quote(s):
    try:
        from urllib.parse import quote_plus
    except:
        from urllib import quote_plus
    return quote_plus(s)

# ----------------------
# Elementum play
# ----------------------
def play_with_elementum(raw_link):
    debug(raw_link)
    try:
        from urllib.parse import quote_plus, unquote_plus
    except:
        from urllib import quote_plus, unquote_plus
    try:
        link = unquote_plus(raw_link)
    except:
        link = raw_link
    try:
        elementum_url = f"plugin://plugin.video.elementum/play?uri={quote_plus(link)}"
        xbmc.Player().play(elementum_url)
    except Exception as e:
        xbmc.log(f"[alphatorrent] play error: {e}", xbmc.LOGERROR)
        try:
            xbmc.executebuiltin(f'RunPlugin({elementum_url})')
        except:
            pass

# ----------------------
# Router
# ----------------------
def router(params):
    if "play" in params:
        play_with_elementum(params["play"])
        return
    if "addfav" in params:
        fav_add(params.get("title", "Sem título"), params["addfav"], "", "")
        return
    if "debug" in params:
        debug(params["debug"])
        return
    if "favoritos" in params:
        fav_list()
        return

    items = load_items()
    # entry para favoritos
    li = xbmcgui.ListItem(label="[FAVORITOS]")
    xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?favoritos=1", li, True)

    for it in items:
        add_list_item(it.get("title","Sem título"), it.get("link",""), it.get("thumb",""), it.get("plot",""))

    xbmcplugin.endOfDirectory(addon_handle)

# ----------------------
# MAIN
# ----------------------
if __name__ == "__main__":
    try:
        import urllib.parse as urlparse
    except:
        import urlparse
    qs = sys.argv[2][1:] if len(sys.argv) > 2 else ""
    params = dict(urlparse.parse_qsl(qs))
    router(params)