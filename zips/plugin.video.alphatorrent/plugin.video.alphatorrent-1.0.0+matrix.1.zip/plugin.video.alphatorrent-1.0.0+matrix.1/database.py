import xbmc, xbmcvfs
import sqlite3
import datetime
import os

dir_database = xbmcvfs.translatePath("special://profile/Database")
db = os.path.join(dir_database, 'Addons33.db')

def initialize_database():
    try:
        conn = sqlite3.connect(db)
        cursor = conn.cursor()
        # Cria a tabela se não existir
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS content (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                magnet TEXT NOT NULL,
                tipo TEXT NOT NULL,
                data_adicionado TEXT NOT NULL
            )
        ''')
        conn.commit()
        conn.close()
    except Exception as e:
        xbmc.log(f"Erro ao inicializar o banco de dados: {e}", level=xbmc.LOGERROR)

def insert_content(nome, magnet, tipo):
    try:
        now = datetime.datetime.now()
        data_adicionado = now.strftime("%Y-%m-%d %H:%M:%S")
        conn = sqlite3.connect(db)
        cursor = conn.cursor()
        sql = 'INSERT INTO content (nome, magnet, tipo, data_adicionado) VALUES (?, ?, ?, ?)'
        cursor.execute(sql, (nome, magnet, tipo, data_adicionado))
        conn.commit()
        conn.close()
    except Exception as e:
        xbmc.log(f"Erro ao inserir conteúdo: {e}", level=xbmc.LOGERROR)

def delete_content(content_id):
    try:
        conn = sqlite3.connect(db)
        cursor = conn.cursor()
        sql = 'DELETE FROM content WHERE id=?'
        cursor.execute(sql, (content_id,))
        conn.commit()
        conn.close()
    except Exception as e:
        xbmc.log(f"Erro ao deletar conteúdo: {e}", level=xbmc.LOGERROR)

def update_content(content_id, nome, magnet):
    try:
        conn = sqlite3.connect(db)
        cursor = conn.cursor()
        sql = 'UPDATE content SET nome=?, magnet=? WHERE id=?'
        cursor.execute(sql, (nome, magnet, content_id))
        conn.commit()
        conn.close()
    except Exception as e:
        xbmc.log(f"Erro ao atualizar conteúdo: {e}", level=xbmc.LOGERROR)

def get_all_content():
    try:
        conn = sqlite3.connect(db)
        cursor = conn.cursor()
        sql = 'SELECT * FROM content'
        cursor.execute(sql)
        rows = cursor.fetchall()
        conn.close()
        return rows
    except Exception as e:
        xbmc.log(f"Erro ao obter conteúdo: {e}", level=xbmc.LOGERROR)
        return []

# Inicializa o banco de dados ao iniciar o add-on
initialize_database()