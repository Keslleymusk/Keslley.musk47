import zipfile
import xbmcgui
import xbmc

def extract_zip(_in, _out, dp=None):
    """
    Extrai arquivos de um arquivo ZIP para um diretório de destino.
    
    :param _in: Caminho do arquivo ZIP de entrada
    :param _out: Caminho do diretório de saída onde os arquivos serão extraídos
    :param dp: Diálogo de progresso (opcional)
    :return: True se a extração for bem-sucedida, False caso contrário
    """
    try:
        with zipfile.ZipFile(_in, 'r') as zin:
            if dp:
                return extract_with_progress(zin, _out, dp)
            else:
                zin.extractall(_out)
                xbmc.log(f"Arquivos extraídos de {_in} para {_out}", level=xbmc.LOGINFO)
    except Exception as e:
        xbmcgui.Dialog().ok("Erro", f"Ocorreu um erro ao extrair o arquivo: {str(e)}")
        xbmc.log(f"Erro ao extrair {_in}: {str(e)}", level=xbmc.LOGERROR)
        return False
    return True

def extract_with_progress(zin, _out, dp):
    """
    Extrai arquivos de um arquivo ZIP com um diálogo de progresso.
    
    :param zin: Objeto ZipFile aberto
    :param _out: Caminho do diretório de saída
    :param dp: Diálogo de progresso
    :return: True se a extração for bem-sucedida, False caso contrário
    """
    nFiles = float(len(zin.infolist()))
    count = 0

    try:
        for item in zin.infolist():
            zin.extract(item, _out)
            count += 1
            update = (count / nFiles) * 100
            dp.update(int(update))
            if dp.iscanceled():
                raise Exception("Extração cancelada pelo usuário")
    except Exception as e:
        xbmcgui.Dialog().ok("Erro", f"Ocorreu um erro ao extrair o arquivo: {str(e)}")
        xbmc.log(f"Erro ao extrair: {str(e)}", level=xbmc.LOGERROR)
        return False

    xbmc.log(f"Extração concluída: {_in} para {_out}", level=xbmc.LOGINFO)
    return True