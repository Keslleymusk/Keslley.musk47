import xbmcgui
import urllib.request as urllib
import os

def download_file(url, dest, dp=None):
    """
    Faz o download de um arquivo de uma URL para um destino especificado.
    :param url: URL do arquivo a ser baixado
    :param dest: Caminho de destino onde o arquivo será salvo
    :param dp: Diálogo de progresso opcional
    """
    if not dp:
        dp = xbmcgui.DialogProgress()
        dp.create("alphatorrent", "Baixando e copiando arquivo", '', '')
    
    dp.update(0)

    # Verifica se o diretório de destino existe; caso contrário, cria-o
    dest_dir = os.path.dirname(dest)
    if not os.path.exists(dest_dir):
        os.makedirs(dest_dir)

    try:
        urllib.urlretrieve(url, dest, lambda nb, bs, fs, url=url: _pbhook(nb, bs, fs, url, dp))
        dp.close()
    except Exception as e:
        xbmcgui.Dialog().ok("Erro", f"Ocorreu um erro durante o download: {str(e)}")
        if dp:
            dp.close()

def _pbhook(numblocks, blocksize, filesize, url, dp):
    """
    Função de callback para atualizar o diálogo de progresso.
    :param numblocks: Número de blocos baixados
    :param blocksize: Tamanho de cada bloco
    :param filesize: Tamanho total do arquivo
    :param url: URL do arquivo
    :param dp: Diálogo de progresso
    """
    try:
        percent = min((numblocks * blocksize * 100) / filesize, 100)
        dp.update(percent)
    except Exception:
        percent = 100
        dp.update(percent)
    
    if dp.iscanceled():
        raise Exception("Cancelado")