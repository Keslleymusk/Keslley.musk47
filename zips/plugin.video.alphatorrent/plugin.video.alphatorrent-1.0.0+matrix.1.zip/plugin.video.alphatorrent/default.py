# -*- coding: utf-8 -*-
# AlphaTorrent
# Desenvolvido por @keslley.musk47 

import sys, os, json, re
import urllib.request
import urllib.parse as urlparse
import xml.etree.ElementTree as ET

import xbmc, xbmcgui, xbmcplugin, xbmcaddon

# -------------------------------------------------------------------
# PATHS
# -------------------------------------------------------------------
addon        = xbmcaddon.Addon()
addon_icon   = addon.getAddonInfo("icon")
addon_handle = int(sys.argv[1])

try:
    import xbmcvfs
    translate = xbmcvfs.translatePath
except:
    translate = xbmc.translatePath

FAV_PATH = translate("special://home/alphatorrent_favorites.json")

URL_PRINCIPAL = "https://raw.githubusercontent.com/Keslleymusk/Keslley.musk47/main/README.md"

USER_AGENT = {"User-Agent": "Mozilla/5.0"}

# -------------------------------------------------------------------
# HTTP SAFE
# -------------------------------------------------------------------
def http_get(url):
    try:
        req = urllib.request.Request(url, headers=USER_AGENT)
        with urllib.request.urlopen(req, timeout=20) as r:
            return r.read().decode("utf-8", "ignore")
    except:
        return ""

# -------------------------------------------------------------------
# FAVORITOS
# -------------------------------------------------------------------
def fav_load():
    return json.load(open(FAV_PATH, "r", encoding="utf-8")) if os.path.exists(FAV_PATH) else []

def fav_save(data):
    json.dump(data, open(FAV_PATH, "w", encoding="utf-8"), indent=2, ensure_ascii=False)

def fav_add(title, link, thumb, plot):
    favs = fav_load()
    item = {"title": title, "link": link, "thumb": thumb, "plot": plot}
    if item not in favs:
        favs.append(item)
        fav_save(favs)
        xbmcgui.Dialog().notification("Favoritos", "Adicionado", addon_icon, 3000)

# -------------------------------------------------------------------
# PARSE UNIVERSAL (COMPATÍVEL COM O CÓDIGO GRANDE)
# -------------------------------------------------------------------
def parse_xml(xml):
    try:
        xml = xml.replace("&", "&amp;")
        root = ET.fromstring(xml)
    except:
        return [], []

    channels = []
    items = []

    # <channel>
    for c in root.findall(".//channel"):
        name   = c.findtext("name") or ""
        link   = c.findtext("externallink") or c.findtext("url") or ""
        thumb  = c.findtext("thumbnail") or ""
        fanart = c.findtext("fanart") or ""

        if name and link:
            channels.append({
                "name": name,
                "link": link,
                "thumb": thumb,
                "fanart": fanart
            })

    # <item>
    for it in root.findall(".//item"):
        title = it.findtext("title") or ""
        link  = it.findtext("link") or ""
        thumb = it.findtext("thumbnail") or ""
        plot  = it.findtext("info") or ""

        # multilink: <link>magnet1||magnet2</link>
        if "||" in link:
            links = link.split("||")
            link = links[0]  # default

        if title and link:
            items.append({
                "title": title,
                "link": link,
                "thumb": thumb,
                "plot": plot
            })

    return channels, items

# -------------------------------------------------------------------
# LISTAGEM
# -------------------------------------------------------------------
from urllib.parse import quote_plus

def add_menu_item(name, link, thumb, fanart):
    li = xbmcgui.ListItem(label=name)
    li.setArt({"thumb": thumb, "icon": thumb, "fanart": fanart})
    li.addContextMenuItems([
        ("DEBUG URL", f"RunPlugin({sys.argv[0]}?debug={quote_plus(link)})")
    ])
    url = f"{sys.argv[0]}?menu={quote_plus(link)}"
    xbmcplugin.addDirectoryItem(addon_handle, url, li, True)


def add_video_item(title, link, thumb, plot, fanart=None):
    li = xbmcgui.ListItem(label=title)
    li.setInfo("video", {"title": title, "plot": plot})
    li.setArt({"thumb": thumb, "icon": thumb, "fanart": fanart})

    li.addContextMenuItems([
        ("Favorito", f"RunPlugin({sys.argv[0]}?addfav={quote_plus(link)}&title={quote_plus(title)}&thumb={quote_plus(thumb)}&plot={quote_plus(plot)})"),
        ("DEBUG URL", f"RunPlugin({sys.argv[0]}?debug={quote_plus(link)})")
    ])

    url = f"{sys.argv[0]}?play={quote_plus(link)}"
    xbmcplugin.addDirectoryItem(addon_handle, url, li, False)

# -------------------------------------------------------------------
# PLAYER (ELEMENTUM)
# -------------------------------------------------------------------
def play_torrent(raw):
    # magnet, file.torrent, m3u, http .torrent → tudo funciona no Elementum
    uri = f"plugin://plugin.video.elementum/play?uri={quote_plus(raw)}"
    xbmc.Player().play(uri)

# -------------------------------------------------------------------
# ROUTER
# -------------------------------------------------------------------
def router(params):

    # PLAY
    if "play" in params:
        play_torrent(params["play"])
        return

    # FAVORITO
    if "addfav" in params:
        fav_add(params["title"], params["addfav"], params.get("thumb",""), params.get("plot",""))
        return

    # DEBUG
    if "debug" in params:
        xbmcgui.Dialog().textviewer("DEBUG", params["debug"])
        return

    # MENU PROFUNDO
    if "menu" in params:
        xml = http_get(params["menu"])
        channels, items = parse_xml(xml)

        for c in channels:
            add_menu_item(c["name"], c["link"], c["thumb"], c["fanart"])

        for it in items:
            add_video_item(it["title"], it["link"], it["thumb"], it["plot"])

        xbmcplugin.endOfDirectory(addon_handle)
        return

    # MENU PRINCIPAL
    xml = http_get(URL_PRINCIPAL)
    channels, items = parse_xml(xml)

    for c in channels:
        add_menu_item(c["name"], c["link"], c["thumb"], c["fanart"])

    for it in items:
        add_video_item(it["title"], it["link"], it["thumb"], it["plot"])

    xbmcplugin.endOfDirectory(addon_handle)

# -------------------------------------------------------------------
# MAIN
# -------------------------------------------------------------------
qs = sys.argv[2][1:] if len(sys.argv) > 2 else ""
params = dict(urlparse.parse_qsl(qs))
router(params)
