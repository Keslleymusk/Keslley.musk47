# -*- coding: utf-8 -*-
# Desenvolvido por @keslley.musk47  27/11/2025

import sys
import json
import urllib.request
import xml.etree.ElementTree as ET
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import os

# ----------------------------------------------------------
# translate universal
# ----------------------------------------------------------
try:
    import xbmcvfs
except:
    xbmcvfs = None

def translate(path):
    try:
        if xbmcvfs and hasattr(xbmcvfs, "translatePath"):
            return xbmcvfs.translatePath(path)
    except:
        pass
    try:
        if hasattr(xbmc, "translatePath"):
            return xbmc.translatePath(path)
    except:
        pass
    return path

addon = xbmcaddon.Addon()
addon_icon = addon.getAddonInfo("icon")
addon_handle = int(sys.argv[1])

URL_PRINCIPAL = "https://raw.githubusercontent.com/Keslleymusk/Keslley.musk47/main/README.md"
FAV_FILE = translate("special://home/alphatorrent_favorites.json")

# ----------------------------------------------------------
# DEBUG
# ----------------------------------------------------------
def debug(msg):
    xbmcgui.Dialog().ok("DEBUG", str(msg))

# ----------------------------------------------------------
# FAVORITOS
# ----------------------------------------------------------
def fav_load():
    if os.path.exists(FAV_FILE):
        try:
            return json.load(open(FAV_FILE, "r", encoding="utf-8"))
        except:
            return json.load(open(FAV_FILE, "r"))
    return []

def fav_save(data):
    try:
        json.dump(data, open(FAV_FILE, "w", encoding="utf-8"), indent=2)
    except:
        json.dump(data, open(FAV_FILE, "w"), indent=2)

def fav_add(title, link, thumb, plot):
    favs = fav_load()
    item = {"title": title, "link": link, "thumb": thumb, "plot": plot}
    if item not in favs:
        favs.append(item)
        fav_save(favs)
        xbmcgui.Dialog().notification("Favoritos", "Adicionado!", addon_icon, 2000)

# ----------------------------------------------------------
# HTTP SAFE
# ----------------------------------------------------------
def get_request(url):
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        data = urllib.request.urlopen(req, timeout=20).read()
        text = data.decode("utf-8", errors="ignore")
        if "<html" in text.lower():
            return ""  # evita “lixo” vindo do GitHub
        return text
    except:
        return ""

# ----------------------------------------------------------
# PARSE <channel>
# ----------------------------------------------------------
def parse_channels(text):
    items = []
    try:
        root = ET.fromstring(text)
        for c in root.findall(".//channel"):
            name   = c.findtext("name") or ""
            link   = c.findtext("externallink") or ""
            thumb  = c.findtext("thumbnail") or ""
            fanart = c.findtext("fanart") or ""
            if name and link:
                items.append({
                    "type": "channel",
                    "name": name,
                    "link": link,
                    "thumb": thumb,
                    "fanart": fanart
                })
    except:
        pass
    return items

# ----------------------------------------------------------
# PARSE <item>
# ----------------------------------------------------------
def parse_items(text):
    items = []
    try:
        root = ET.fromstring(text)
        for it in root.findall(".//item"):
            title = it.findtext("title") or ""
            link  = it.findtext("link") or ""
            thumb = it.findtext("thumbnail") or ""
            plot  = it.findtext("info") or ""
            if title and link:
                items.append({
                    "type": "item",
                    "title": title,
                    "link": link,
                    "thumb": thumb,
                    "plot": plot
                })
    except:
        pass
    return items

# ----------------------------------------------------------
# LISTAGEM
# ----------------------------------------------------------
def add_menu_item(name, link, thumb, fanart):
    li = xbmcgui.ListItem(label=name)
    li.setArt({"thumb": thumb, "icon": thumb, "fanart": fanart})
    li.addContextMenuItems([("DEBUG URL", f"RunPlugin({sys.argv[0]}?debug={link})")])
    xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?menu={link}", li, True)

def add_video_item(title, link, thumb, plot):
    li = xbmcgui.ListItem(label=title)
    li.setInfo("video", {"title": title, "plot": plot})
    li.setArt({"thumb": thumb, "icon": thumb})
    li.addContextMenuItems([
        ("Adicionar aos Favoritos", f"RunPlugin({sys.argv[0]}?addfav={link}&title={title})"),
        ("DEBUG URL", f"RunPlugin({sys.argv[0]}?debug={link})")
    ])
    xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?play={link}", li, False)

# ----------------------------------------------------------
# PLAYER
# ----------------------------------------------------------
def play_with_elementum(raw):
    debug(raw)
    try:
        from urllib.parse import quote_plus
    except:
        from urllib import quote_plus
    xbmc.Player().play(f"plugin://plugin.video.elementum/play?uri={quote_plus(raw)}")

# ----------------------------------------------------------
# ROUTER
# ----------------------------------------------------------
def router(params):

    if "play" in params:
        play_with_elementum(params["play"])
        return

    if "addfav" in params:
        fav_add(params.get("title", "Sem título"), params["addfav"], "", "")
        return

    if "debug" in params:
        debug(params["debug"])
        return

    if "menu" in params:
        xml = get_request(params["menu"])

        # Pode ser channel ou item
        channels = parse_channels(xml)
        items    = parse_items(xml)

        if channels:
            for c in channels:
                add_menu_item(c["name"], c["link"], c["thumb"], c["fanart"])
        if items:
            for it in items:
                add_video_item(it["title"], it["link"], it["thumb"], it["plot"])

        xbmcplugin.endOfDirectory(addon_handle)
        return

    # MENU PRINCIPAL
    xml = get_request(URL_PRINCIPAL)
    channels = parse_channels(xml)

    for c in channels:
        add_menu_item(c["name"], c["link"], c["thumb"], c["fanart"])

    xbmcplugin.endOfDirectory(addon_handle)

# ----------------------------------------------------------
# MAIN
# ----------------------------------------------------------
if __name__ == "__main__":
    import urllib.parse as urlparse
    qs = sys.argv[2][1:] if len(sys.argv) > 2 else ""
    router(dict(urlparse.parse_qsl(qs)))
