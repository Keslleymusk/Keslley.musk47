# -*- coding: utf-8 -*-
#Desenvolvido por @keslley.musk47 

import sys
import json
import urllib.request
import xml.etree.ElementTree as ET
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import os

# ----------------------------------------------------------
# Função translate – Compatível com Kodi 19/20/21
# ----------------------------------------------------------
try:
    import xbmcvfs
except:
    xbmcvfs = None

def translate(path):
    try:
        if xbmcvfs and hasattr(xbmcvfs, "translatePath"):
            return xbmcvfs.translatePath(path)
    except:
        pass
    try:
        if hasattr(xbmc, "translatePath"):
            return xbmc.translatePath(path)
    except:
        pass
    return path

addon = xbmcaddon.Addon()
addon_icon = addon.getAddonInfo("icon")
addon_handle = int(sys.argv[1])

# URL PRINCIPAL – seu menu
URL_PRINCIPAL = "https://raw.githubusercontent.com/Keslleymusk/Keslley.musk47/main/README.md"

# Local dos favoritos
FAV_FILE = translate("special://home/alphatorrent_favorites.json")

# ----------------------------------------------------------
# DEBUG
# ----------------------------------------------------------
def debug(msg):
    xbmcgui.Dialog().ok("DEBUG", str(msg))

# ----------------------------------------------------------
# FAVORITOS
# ----------------------------------------------------------
def fav_load():
    if os.path.exists(FAV_FILE):
        try:
            return json.load(open(FAV_FILE, "r", encoding="utf-8"))
        except:
            return json.load(open(FAV_FILE, "r"))
    return []

def fav_save(data):
    try:
        json.dump(data, open(FAV_FILE, "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    except:
        json.dump(data, open(FAV_FILE, "w"), indent=2)

def fav_add(title, link, thumb, plot):
    favs = fav_load()
    item = {"title": title, "link": link, "thumb": thumb, "plot": plot}
    if item not in favs:
        favs.append(item)
        fav_save(favs)
        xbmcgui.Dialog().notification("Favoritos", "Adicionado!", addon_icon, 2000)

def fav_list():
    for it in fav_load():
        add_video_item(it["title"], it["link"], it["thumb"], it["plot"], is_favorite=False)
    xbmcplugin.endOfDirectory(addon_handle)

# ----------------------------------------------------------
# REQUISIÇÃO REMOTA
# ----------------------------------------------------------
def get_request(url):
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        data = urllib.request.urlopen(req, timeout=15).read()
        return data.decode("utf-8", errors="ignore")
    except:
        xbmcgui.Dialog().notification("Erro", "Falha ao acessar servidor remoto", addon_icon, 3000)
        return ""

# ----------------------------------------------------------
# PARSE DO MENU (<channel>)
# ----------------------------------------------------------
def parse_channels(text):
    items = []
    try:
        root = ET.fromstring(text)
        for ch in root.findall(".//channel"):
            name   = ch.findtext("name") or ""
            thumb  = ch.findtext("thumbnail") or ""
            link   = ch.findtext("externallink") or ""
            fanart = ch.findtext("fanart") or ""
            if name and link:
                items.append({"name": name, "thumb": thumb, "externallink": link, "fanart": fanart})
    except:
        pass
    return items

# ----------------------------------------------------------
# PARSE DOS FILMES (<item>)
# ----------------------------------------------------------
def parse_items(text):
    items = []
    try:
        root = ET.fromstring(text)
        for it in root.findall(".//item"):
            title = it.findtext("title") or ""
            link  = it.findtext("link") or ""
            thumb = it.findtext("thumbnail") or ""
            plot  = it.findtext("info") or ""
            if title and link:
                items.append({"title": title, "link": link, "thumb": thumb, "plot": plot})
    except:
        pass
    return items

# ----------------------------------------------------------
# LISTAGEM DO MENU (usa <channel>)
# ----------------------------------------------------------
def add_menu_item(name, link, thumb, fanart):
    li = xbmcgui.ListItem(label=name)
    li.setArt({"thumb": thumb, "fanart": fanart, "icon": thumb})
    url = f"{sys.argv[0]}?menu={link}"
    xbmcplugin.addDirectoryItem(addon_handle, url, li, True)

# ----------------------------------------------------------
# LISTAGEM DE VÍDEOS (usa <item>)
# ----------------------------------------------------------
def add_video_item(title, link, thumb, plot, is_favorite=True):
    li = xbmcgui.ListItem(label=title)
    li.setInfo("video", {"title": title, "plot": plot})
    li.setArt({"thumb": thumb, "icon": thumb})

    # Menu de contexto
    ctx = []
    if is_favorite:
        ctx.append(("Adicionar aos Favoritos", f"RunPlugin({sys.argv[0]}?addfav={link}&title={title})"))
    ctx.append(("DEBUG URL", f"RunPlugin({sys.argv[0]}?debug={link})"))
    li.addContextMenuItems(ctx)

    url = f"{sys.argv[0]}?play={link}"
    xbmcplugin.addDirectoryItem(addon_handle, url, li, False)

# ----------------------------------------------------------
# PLAYER ELEMENTUM
# ----------------------------------------------------------
def play_with_elementum(raw_link):
    debug(raw_link)
    try:
        from urllib.parse import quote_plus, unquote_plus
    except:
        from urllib import quote_plus, unquote_plus

    link = unquote_plus(raw_link)
    elemento = f"plugin://plugin.video.elementum/play?uri={quote_plus(link)}"
    xbmc.Player().play(elemento)

# ----------------------------------------------------------
# ROUTER
# ----------------------------------------------------------
def router(params):

    # Reproduzir torrent
    if "play" in params:
        play_with_elementum(params["play"])
        return

    # Entrar em um sub-menu (<channel>)
    if "menu" in params:
        xml = get_request(params["menu"])
        for it in parse_items(xml):
            add_video_item(it["title"], it["link"], it["thumb"], it["plot"])
        xbmcplugin.endOfDirectory(addon_handle)
        return

    # Favoritos
    if "addfav" in params:
        fav_add(params.get("title", "Sem título"), params["addfav"], "", "")
        return

    if "debug" in params:
        debug(params["debug"])
        return

    if "favoritos" in params:
        fav_list()
        return

    # MENU PRINCIPAL (primeiro XML)
    xml = get_request(URL_PRINCIPAL)

    # Favoritos no topo
    li = xbmcgui.ListItem(label="[FAVORITOS]")
    xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?favoritos=1", li, True)

    # Lista os canais
    for ch in parse_channels(xml):
        add_menu_item(ch["name"], ch["externallink"], ch["thumb"], ch["fanart"])

    xbmcplugin.endOfDirectory(addon_handle)

# ----------------------------------------------------------
# MAIN
# ----------------------------------------------------------
if __name__ == "__main__":
    import urllib.parse as urlparse
    qs = sys.argv[2][1:] if len(sys.argv) > 2 else ""
    router(dict(urlparse.parse_qsl(qs)))
