# -*- coding: utf-8 -*-
# desenvolvido por @keslley.musk47 – Torrent + Servidor Remoto + Favoritos + Debug

import sys
import json
import urllib.request
import xml.etree.ElementTree as ET
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import os

addon       = xbmcaddon.Addon()
addon_name  = addon.getAddonInfo('name')
addon_icon  = addon.getAddonInfo('icon')
addon_path  = addon.getAddonInfo('profile')
addon_handle = int(sys.argv[1])

# URL do servidor remoto
URL_PRINCIPAL = 'https://raw.githubusercontent.com/Keslleymusk/Keslley.musk47/main/README.md'

# Arquivo de favoritos
FAV_FILE = os.path.join(addon_path, "favorites.json")
if not os.path.exists(addon_path):
    os.makedirs(addon_path)

# ----------------------
# DEBUG – exibe a URL clicada
# ----------------------
def debug(msg):
    xbmcgui.Dialog().ok("DEBUG", str(msg))


# ----------------------
# Favoritos (versão otimizada)
# ----------------------
def fav_load():
    if os.path.exists(FAV_FILE):
        try:
            return json.load(open(FAV_FILE))
        except:
            return []
    return []

def fav_save(data):
    json.dump(data, open(FAV_FILE, "w"), indent=2)

def fav_add(title, link, thumb, plot):
    favs = fav_load()
    item = {"title": title, "link": link, "thumb": thumb, "plot": plot}
    if item not in favs:
        favs.append(item)
        fav_save(favs)
        xbmcgui.Dialog().notification("Favoritos", "Adicionado!", addon_icon, 2000)

def fav_list():
    favs = fav_load()
    for it in favs:
        add_list_item(it["title"], it["link"], it["thumb"], it["plot"], is_favorite=False)
    xbmcplugin.endOfDirectory(addon_handle)


# ----------------------
# Requisição remota
# ----------------------
def get_request(url):
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        data = urllib.request.urlopen(req).read()
        try:
            return data.decode("utf-8")
        except:
            return data.decode("latin-1", errors="ignore")
    except Exception as e:
        xbmcgui.Dialog().notification("Erro", "Falha ao acessar servidor", addon_icon, 3000)
        return ""


# ----------------------
# Parser XML simples
# ----------------------
def parse_xml(text):
    items = []
    try:
        root = ET.fromstring(text)
        for it in root.findall(".//item"):
            title = it.findtext("title") or it.findtext("name") or ""
            link  = it.findtext("link") or it.findtext("externallink") or ""
            thumb = it.findtext("thumbnail") or ""
            plot  = it.findtext("info") or ""
            if title and link:
                items.append({"title": title, "link": link, "thumb": thumb, "plot": plot})
    except:
        pass
    return items


# ----------------------
# Parser JSON simples
# ----------------------
def parse_json(text):
    try:
        data = json.loads(text)
    except:
        return []

    if isinstance(data, dict):
        data = data.get("items") or data.get("data") or []

    items = []
    for it in data:
        title = it.get("title") or it.get("name") or ""
        link  = it.get("link") or it.get("magnet") or ""
        thumb = it.get("thumbnail") or ""
        plot  = it.get("info") or ""
        if title and link:
            items.append({"title": title, "link": link, "thumb": thumb, "plot": plot})
    return items


# ----------------------
# Resolver feed remoto
# ----------------------
def load_items():
    text = get_request(URL_PRINCIPAL)
    if not text:
        return []

    # JSON primeiro
    if text.strip().startswith("{") or text.strip().startswith("["):
        itens = parse_json(text)
        if itens:
            return itens

    # Senão XML
    return parse_xml(text)


# ----------------------
# Listagem geral
# ----------------------
def add_list_item(title, link, thumb, plot, is_favorite=True):
    li = xbmcgui.ListItem(label=title)
    li.setInfo("video", {"title": title, "plot": plot})
    if thumb:
        li.setArt({"thumb": thumb, "icon": thumb})

    # URL para ação
    url = f"{sys.argv[0]}?play={link}"

    # Menu de contexto (favoritos)
    menu = []
    if is_favorite:
        menu.append(("Adicionar aos Favoritos", f"RunPlugin({sys.argv[0]}?addfav={link}&title={title})"))
    menu.append(("Mostrar URL (DEBUG)", f"RunPlugin({sys.argv[0]}?debug={link})"))
    li.addContextMenuItems(menu, replaceItems=False)

    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)


# ----------------------
# Player Elementum
# ----------------------
def play_with_elementum(raw_link):
    debug(raw_link)  # DEBUG EXIBE A URL EXATAMENTE COMO VOCÊ PEDIU

    try:
        from urllib.parse import quote_plus, unquote_plus
    except:
        from urllib import quote_plus, unquote_plus

    link = unquote_plus(raw_link)

    elementum_url = f"plugin://plugin.video.elementum/play?uri={quote_plus(link)}"
    xbmc.Player().play(elementum_url)


# ----------------------
# Router (ações)
# ----------------------
def router(params):
    # PLAY
    if "play" in params:
        play_with_elementum(params["play"])
        return

    # ADD FAVORITO
    if "addfav" in params:
        fav_add(params.get("title", "Sem título"), params["addfav"], "", "")
        return

    # DEBUG URL
    if "debug" in params:
        debug(params["debug"])
        return

    # LISTA DE FAVORITOS
    if "favoritos" in params:
        fav_list()
        return

    # MENU INICIAL
    items = load_items()

    # Entrada do menu de favoritos
    li = xbmcgui.ListItem(label="[FAVORITOS]")
    xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?favoritos=1", li, isFolder=True)

    # Items do servidor remoto
    for it in items:
        add_list_item(it["title"], it["link"], it["thumb"], it["plot"])

    xbmcplugin.endOfDirectory(addon_handle)


# ----------------------
# MAIN
# ----------------------
if __name__ == "__main__":
    import urllib.parse as urlparse
    qs = sys.argv[2][1:] if len(sys.argv) > 2 else ""
    params = dict(urlparse.parse_qsl(qs))
    router(params)