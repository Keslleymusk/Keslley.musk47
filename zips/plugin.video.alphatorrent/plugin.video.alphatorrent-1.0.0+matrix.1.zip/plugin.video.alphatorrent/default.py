# -*- coding: utf-8 -*-
# Versão otimizada por Lucy – Torrent + Servidor Remoto + Favoritos + Debug (versão estável)

import sys
import json
import urllib.request
import xml.etree.ElementTree as ET
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import os

# -----------------------------------------------------------------------------
# Função translate universal (corrige o problema do translatePath em TODAS as versões)
# -----------------------------------------------------------------------------
try:
    import xbmcvfs
except:
    xbmcvfs = None

def translate(path):
    try:
        if xbmcvfs and hasattr(xbmcvfs, "translatePath"):
            return xbmcvfs.translatePath(path)
    except:
        pass
    try:
        if hasattr(xbmc, "translatePath"):
            return xbmc.translatePath(path)
    except:
        pass
    return path

# -----------------------------------------------------------------------------

addon = xbmcaddon.Addon()
addon_icon = addon.getAddonInfo("icon")
addon_handle = int(sys.argv[1])

# URL remota do usuário
URL_PRINCIPAL = "https://raw.githubusercontent.com/Keslleymusk/Keslley.musk47/main/README.md"

# Local definitivo dos favoritos (não dá erro no Android)
FAV_FILE = translate("special://home/alphatorrent_favorites.json")

# -----------------------------------------------------------------------------
# DEBUG
# -----------------------------------------------------------------------------
def debug(msg):
    xbmcgui.Dialog().ok("DEBUG", str(msg))

# -----------------------------------------------------------------------------
# FAVORITOS
# -----------------------------------------------------------------------------
def fav_load():
    if os.path.exists(FAV_FILE):
        try:
            return json.load(open(FAV_FILE, "r", encoding="utf-8"))
        except:
            try:
                return json.load(open(FAV_FILE, "r"))
            except:
                return []
    return []

def fav_save(data):
    try:
        json.dump(data, open(FAV_FILE, "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    except:
        json.dump(data, open(FAV_FILE, "w"), indent=2)

def fav_add(title, link, thumb, plot):
    favs = fav_load()
    item = {"title": title, "link": link, "thumb": thumb, "plot": plot}
    if item not in favs:
        favs.append(item)
        fav_save(favs)
        xbmcgui.Dialog().notification("Favoritos", "Adicionado!", addon_icon, 2000)

def fav_list():
    for it in fav_load():
        add_list_item(it["title"], it["link"], it["thumb"], it["plot"], is_favorite=False)
    xbmcplugin.endOfDirectory(addon_handle)

# -----------------------------------------------------------------------------
# REQUISIÇÃO REMOTA
# -----------------------------------------------------------------------------
def get_request(url):
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        data = urllib.request.urlopen(req, timeout=15).read()
        try:
            return data.decode("utf-8")
        except:
            return data.decode("latin-1", errors="ignore")
    except:
        xbmcgui.Dialog().notification("Erro", "Servidor indisponível", addon_icon, 3000)
        return ""

# -----------------------------------------------------------------------------
# PARSE XML / JSON
# -----------------------------------------------------------------------------
def parse_xml(text):
    items = []
    try:
        root = ET.fromstring(text)
        for it in root.findall(".//item"):
            title = it.findtext("title") or ""
            link  = it.findtext("link") or ""
            thumb = it.findtext("thumbnail") or ""
            plot  = it.findtext("info") or ""
            if title and link:
                items.append({"title": title.strip(), "link": link.strip(), "thumb": thumb.strip(), "plot": plot.strip()})
    except:
        pass
    return items

def parse_json(text):
    try:
        data = json.loads(text)
    except:
        return []

    if isinstance(data, dict):
        data = data.get("items") or data.get("data") or []

    items = []
    for it in data:
        if not isinstance(it, dict):
            continue
        title = it.get("title") or ""
        link  = it.get("link") or it.get("magnet") or ""
        thumb = it.get("thumbnail") or ""
        plot  = it.get("info") or ""
        if title and link:
            items.append({"title": title.strip(), "link": link.strip(), "thumb": thumb.strip(), "plot": plot.strip()})
    return items

# -----------------------------------------------------------------------------
# CARREGAR FEED
# -----------------------------------------------------------------------------
def load_items():
    text = get_request(URL_PRINCIPAL)
    if not text:
        return []
    st = text.strip()
    if st.startswith("{") or st.startswith("["):
        items = parse_json(text)
        if items:
            return items
    return parse_xml(text)

# -----------------------------------------------------------------------------
# LISTAGEM
# -----------------------------------------------------------------------------
def quote(s):
    try:
        from urllib.parse import quote_plus
    except:
        from urllib import quote_plus
    return quote_plus(s)

def add_list_item(title, link, thumb, plot, is_favorite=True):
    li = xbmcgui.ListItem(label=title)
    li.setInfo("video", {"title": title, "plot": plot})

    if thumb:
        li.setArt({"thumb": thumb, "icon": thumb})

    url = f"{sys.argv[0]}?play={quote(link)}"

    menu = []
    if is_favorite:
        menu.append(("Adicionar aos Favoritos", f"RunPlugin({sys.argv[0]}?addfav={quote(link)}&title={quote(title)})"))
    menu.append(("DEBUG URL", f"RunPlugin({sys.argv[0]}?debug={quote(link)})"))

    li.addContextMenuItems(menu)

    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)

# -----------------------------------------------------------------------------
# ELEMENTUM
# -----------------------------------------------------------------------------
def play_with_elementum(raw_link):
    debug(raw_link)
    try:
        from urllib.parse import quote_plus, unquote_plus
    except:
        from urllib import quote_plus, unquote_plus

    link = unquote_plus(raw_link)
    elementum_url = f"plugin://plugin.video.elementum/play?uri={quote_plus(link)}"
    xbmc.Player().play(elementum_url)

# -----------------------------------------------------------------------------
# ROUTER
# -----------------------------------------------------------------------------
def router(params):
    if "play" in params:
        play_with_elementum(params["play"])
        return

    if "addfav" in params:
        fav_add(params.get("title", "Sem título"), params["addfav"], "", "")
        return

    if "debug" in params:
        debug(params["debug"])
        return

    if "favoritos" in params:
        fav_list()
        return

    # MENU PRINCIPAL
    li = xbmcgui.ListItem(label="[FAVORITOS]")
    xbmcplugin.addDirectoryItem(addon_handle, f"{sys.argv[0]}?favoritos=1", li, True)

    for it in load_items():
        add_list_item(it["title"], it["link"], it["thumb"], it["plot"])

    xbmcplugin.endOfDirectory(addon_handle)

# -----------------------------------------------------------------------------
# MAIN
# -----------------------------------------------------------------------------
if __name__ == "__main__":
    import urllib.parse as urlparse
    qs = sys.argv[2][1:] if len(sys.argv) > 2 else ""
    params = dict(urlparse.parse_qsl(qs))
    router(params)