# -*- coding: utf-8 -*-
# Desenvolvido por @keslley.musk47 – versão corrigida e refatorada

import sys
import json
import urllib.request
import xml.etree.ElementTree as ET
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import os
import urllib.parse as urlparse

try:
    import xbmcvfs
except ImportError:
    xbmcvfs = None

def translate(path):
    try:
        if xbmcvfs and hasattr(xbmcvfs, "translatePath"):
            return xbmcvfs.translatePath(path)
    except Exception as e:
        xbmc.log(f"Erro em xbmcvfs.translatePath: {e}", xbmc.LOGERROR)
    try:
        if hasattr(xbmc, "translatePath"):
            return xbmc.translatePath(path)
    except Exception as e:
        xbmc.log(f"Erro em xbmc.translatePath: {e}", xbmc.LOGERROR)
    return path

addon = xbmcaddon.Addon()
addon_icon = addon.getAddonInfo("icon")
addon_handle = int(sys.argv[1])

URL_PRINCIPAL = "https://raw.githubusercontent.com/Keslleymusk/Keslley.musk47/main/README.md"
FAV_FILE = translate("special://home/alphatorrent_favorites.json")

# ----------------------------------------------------------
# DEBUG
# ----------------------------------------------------------
def debug(msg):
    xbmcgui.Dialog().ok("DEBUG", str(msg))
    xbmc.log(f"DEBUG: {msg}", xbmc.LOGINFO)

# ----------------------------------------------------------
# FAVORITOS
# ----------------------------------------------------------
def fav_load():
    if os.path.exists(FAV_FILE):
        try:
            with open(FAV_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            xbmc.log(f"Erro ao carregar favoritos: {e}", xbmc.LOGERROR)
            try:
                with open(FAV_FILE, "r") as f:
                    return json.load(f)
            except Exception as e2:
                xbmc.log(f"Erro secundário ao carregar favoritos: {e2}", xbmc.LOGERROR)
    return []

def fav_save(data):
    try:
        with open(FAV_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except Exception as e:
        xbmc.log(f"Erro ao salvar favoritos: {e}", xbmc.LOGERROR)
        try:
            with open(FAV_FILE, "w") as f:
                json.dump(data, f, indent=2)
        except Exception as e2:
            xbmc.log(f"Erro secundário ao salvar favoritos: {e2}", xbmc.LOGERROR)

def fav_add(title, link, thumb, plot):
    favs = fav_load()
    item = {"title": title, "link": link, "thumb": thumb, "plot": plot}
    if item not in favs:
        favs.append(item)
        fav_save(favs)
        xbmcgui.Dialog().notification("Favoritos", "Adicionado!", addon_icon, 3000)

# ----------------------------------------------------------
# HTTP SAFE
# ----------------------------------------------------------
def get_request(url):
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=20) as response:
            data = response.read()
        return data.decode("utf-8", errors="ignore")
    except Exception as e:
        xbmc.log(f"Erro em get_request: {e}", xbmc.LOGERROR)
        return ""

# ----------------------------------------------------------
# PARSE <channel>
# ----------------------------------------------------------
def parse_channels(text):
    items = []
    try:
        root = ET.fromstring(text)
        for c in root.findall(".//channel"):
            name   = c.findtext("name") or ""
            link   = c.findtext("externallink") or ""
            thumb  = c.findtext("thumbnail") or ""
            fanart = c.findtext("fanart") or ""
            if name and link:
                items.append({
                    "type": "channel",
                    "name": name,
                    "link": link,
                    "thumb": thumb,
                    "fanart": fanart
                })
    except Exception as e:
        xbmc.log(f"Erro em parse_channels: {e}", xbmc.LOGERROR)
    return items

# ----------------------------------------------------------
# PARSE <item>
# ----------------------------------------------------------
def parse_items(text):
    items = []
    try:
        root = ET.fromstring(text)
        for it in root.findall(".//item"):
            title = it.findtext("title") or ""
            link  = it.findtext("link") or ""
            thumb = it.findtext("thumbnail") or ""
            plot  = it.findtext("info") or ""
            if title and link:
                items.append({
                    "type": "item",
                    "title": title,
                    "link": link,
                    "thumb": thumb,
                    "plot": plot
                })
    except Exception as e:
        xbmc.log(f"Erro em parse_items: {e}", xbmc.LOGERROR)
    return items

# ----------------------------------------------------------
# LISTAGEM
# ----------------------------------------------------------
from urllib.parse import quote_plus

def add_menu_item(name, link, thumb, fanart):
    li = xbmcgui.ListItem(label=name)
    li.setArt({"thumb": thumb, "icon": thumb})
    if fanart:
        li.setProperty("fanart_image", fanart)

    li.addContextMenuItems([
        ("DEBUG URL", f"RunPlugin({sys.argv[0]}?debug={quote_plus(link)})")
    ])

    url = f"{sys.argv[0]}?menu={quote_plus(link)}"
    xbmcplugin.addDirectoryItem(addon_handle, url, li, True)

def add_video_item(title, link, thumb, plot, fanart=None):
    li = xbmcgui.ListItem(label=title)
    li.setInfo("video", {"title": title, "plot": plot})
    li.setArt({"thumb": thumb, "icon": thumb})
    if fanart:
        li.setProperty("fanart_image", fanart)

    li.addContextMenuItems([
        ("Adicionar aos Favoritos", f"RunPlugin({sys.argv[0]}?addfav={quote_plus(link)}&title={quote_plus(title)})"),
        ("DEBUG URL", f"RunPlugin({sys.argv[0]}?debug={quote_plus(link)})")
    ])

    url = f"{sys.argv[0]}?play={quote_plus(link)}"
    xbmcplugin.addDirectoryItem(addon_handle, url, li, False)

# ----------------------------------------------------------
# PLAYER
# ----------------------------------------------------------
def play_with_elementum(raw):
    debug(raw)
    xbmc.Player().play(
        f"plugin://plugin.video.elementum/play?uri={quote_plus(raw)}"
    )

# ----------------------------------------------------------
# ROUTER
# ----------------------------------------------------------
def router(params):
    if "play" in params:
        play_with_elementum(params["play"])
        return

    if "addfav" in params:
        fav_add(params.get("title", "Sem título"), params["addfav"], "", "")
        return

    if "debug" in params:
        debug(params["debug"])
        return

    if "menu" in params:
        xml = get_request(params["menu"])
        channels = parse_channels(xml)
        items    = parse_items(xml)

        for c in channels:
            add_menu_item(c["name"], c["link"], c["thumb"], c["fanart"])

        for it in items:
            add_video_item(it["title"], it["link"], it["thumb"], it["plot"])

        xbmcplugin.endOfDirectory(addon_handle)
        return

    # MENU PRINCIPAL
    xml = get_request(URL_PRINCIPAL)
    channels = parse_channels(xml)

    for c in channels:
        add_menu_item(c["name"], c["link"], c["thumb"], c["fanart"])

    xbmcplugin.endOfDirectory(addon_handle)

# ----------------------------------------------------------
# MAIN
# ----------------------------------------------------------
if __name__ == "__main__":
    qs = sys.argv[2][1:] if len(sys.argv) > 2 else ""
    router(dict(urlparse.parse_qsl(qs)))
