# -*- coding: utf-8 -*-
"""
default.py — Versão profissional e corrigida
Objetivo:
- Conectar a lista remota (JSON/XML/M3U)
- Carregar itens com fanarts, ícones e descrições
- Reproduzir magnets/torrents via Elementum
- Interface limpa e funcional no Kodi
"""

from __future__ import print_function
import sys
import os
import time
import json
import base64
import re
import traceback

try:
    from urllib.parse import quote_plus, unquote_plus
except:
    from urllib import quote_plus, unquote_plus

try:
    from urllib.request import Request, urlopen
    from urllib.error import URLError, HTTPError
except:
    from urllib2 import Request, urlopen, URLError, HTTPError  # Python2 fallback

# ====================== KODI IMPORTS ======================
try:
    import xbmc
    import xbmcgui
    import xbmcplugin
    import xbmcaddon
except:
    xbmc = None
    xbmcgui = None
    xbmcplugin = None
    xbmcaddon = None

# ====================== ADDON INFO ========================
ADDON = xbmcaddon.Addon() if xbmcaddon else None
ADDON_ID = ADDON.getAddonInfo("id") if ADDON else "addon.elementum.remote"
ADDON_NAME = ADDON.getAddonInfo("name") if ADDON else "Addon"
ADDON_ICON = ADDON.getAddonInfo("icon") if ADDON else ""

try:
    HANDLE = int(sys.argv[1])
except:
    HANDLE = 0

# ====================== CONFIG ============================
import xbmcvfs

# Caminho temporário seguro e compatível com Matrix/Nexus/Ωmega atualizado 28/11/2025
WORK_DIR = xbmcvfs.translatePath("special://temp/")

LOG_FILE = os.path.join(WORK_DIR, "elementum_remote.log")

CACHE_DIR = os.path.join(WORK_DIR, "cache_elem")
if not os.path.exists(CACHE_DIR):
    try:
        os.makedirs(CACHE_DIR)
    except:
        pass

# URL remota de menu principal
URL_PRINCIPAL = "https://raw.githubusercontent.com/Keslleymusk/Keslley.musk47/main/README.md"


# ====================== LOG ===============================
def log(msg, lvl="INFO"):
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write("[%s] %s: %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), lvl, str(msg)))
    except:
        pass


# ====================== NOTIFICAÇÃO ========================
def notify(msg):
    if xbmcgui:
        xbmcgui.Dialog().notification(ADDON_NAME, str(msg), ADDON_ICON, 4000)
    else:
        log("NOTIFY: %s" % msg)


# ====================== HTTP GET ==========================
def http_get(url, timeout=10):
    try:
        req = Request(url, headers={"User-Agent": "Mozilla/5.0"})
        r = urlopen(req, timeout=timeout)
        data = r.read()
        try:
            return data.decode("utf-8")
        except:
            return data.decode("latin-1")
    except Exception as e:
        log("http_get erro: %s" % str(e), "ERROR")
        return None


# ====================== PARAMS ============================
def get_params():
    p = {}
    if len(sys.argv) < 3:
        return p
    qs = sys.argv[2].lstrip("?")
    for part in qs.split("&"):
        if "=" in part:
            k, v = part.split("=", 1)
            p[k] = unquote_plus(v)
    return p


# ====================== RESOLVER ==========================
def try_base64(s):
    try:
        if len(s) % 4 != 0:
            return None
        decoded = base64.b64decode(s)
        try:
            return decoded.decode("utf-8")
        except:
            return decoded.decode("latin-1")
    except:
        return None


def resolver(url):
    if not url:
        return ""

    url = unquote_plus(url).strip()

    # plugin elementum
    if url.startswith("plugin://plugin.video.elementum/"):
        return url

    # magnet
    if url.startswith("magnet:"):
        return "plugin://plugin.video.elementum/play?uri=%s" % quote_plus(url, safe="")

    # torrent
    if url.lower().endswith(".torrent") or ".torrent?" in url:
        return "plugin://plugin.video.elementum/play?uri=%s" % quote_plus(url, safe="")

    # http direto
    if url.startswith("http://") or url.startswith("https://"):
        return url

    # base64
    b = try_base64(url)
    if b:
        return resolver(b)

    return url


# ====================== PLAYER ============================
def play_item(name, link):
    resolved = resolver(link)
    if not resolved:
        notify("Link inválido")
        return False

    # plugin elementum
    if resolved.startswith("plugin://plugin.video.elementum"):
        try:
            xbmc.executebuiltin("RunPlugin(%s)" % resolved)
        except:
            notify("Erro Elementum")
        return True

    # player normal
    try:
        li = xbmcgui.ListItem(label=name)
        xbmc.Player().play(resolved, li)
        return True
    except Exception as e:
        log("play_item erro: %s" % str(e), "ERROR")
        notify("Erro ao iniciar player")
        return False
        
        
        # ====================== PARSERS UNIVERSAIS ================================

def parse_json(content):
    try:
        data = json.loads(content)
        if isinstance(data, list):
            return data
        return []
    except:
        log("parse_json: erro ao interpretar JSON", "ERROR")
        return []


def parse_xml_items(content):
    """
    XML simples no formato:
    <item>
        <title>Nome</title>
        <url>...</url>
        <thumb>...</thumb>
        <plot>...</plot>
    </item>
    """
    items = []
    try:
        blocks = content.split("<item>")
        for blk in blocks[1:]:
            blk = blk.split("</item>")[0]

            def tag(t):
                a = "<%s>" % t
                b = "</%s>" % t
                if a in blk and b in blk:
                    return blk.split(a)[1].split(b)[0].strip()
                return ""

            items.append({
                "title": tag("title"),
                "url": tag("url"),
                "thumb": tag("thumb"),
                "plot": tag("plot")
            })

        return items
    except:
        log("parse_xml_items erro", "ERROR")
        return []


def parse_m3u(content):
    items = []
    lines = content.splitlines()
    title = None
    logo = None

    for ln in lines:
        ln = ln.strip()

        if ln.startswith("#EXTINF:"):
            # título
            m = re.search(r'tvg-name="([^"]+)"', ln)
            if m:
                title = m.group(1)
            else:
                # texto após vírgula
                if "," in ln:
                    title = ln.split(",", 1)[1].strip()
                else:
                    title = "Sem título"

            # logo
            m2 = re.search(r'tvg-logo="([^"]+)"', ln)
            logo = m2.group(1) if m2 else None

        elif ln.startswith("http://") or ln.startswith("https://"):
            items.append({
                "title": title or "Sem título",
                "url": ln,
                "thumb": logo,
                "plot": ""
            })
            title = None
            logo = None

    return items


# ====================== FORMAT DETECTOR ===================================

def autodetect_list(content):
    data = content.strip()

    # JSON
    if data.startswith("{") or data.startswith("["):
        parsed = parse_json(data)
        if parsed:
            return parsed

    # XML
    if data.startswith("<") and "<item>" in data:
        parsed = parse_xml_items(data)
        if parsed:
            return parsed

    # M3U
    if "#EXTM3U" in data:
        parsed = parse_m3u(data)
        if parsed:
            return parsed

    # Fallback -> extrair URLs
    fallback = []
    for ln in data.splitlines():
        ln = ln.strip()
        if ln.startswith("http://") or ln.startswith("https://"):
            fallback.append({"title": ln, "url": ln})
    return fallback


# ====================== CACHE SIMPLES =====================================

def cache_path(key):
    name = re.sub(r"[^A-Za-z0-9_-]+", "_", key)
    return os.path.join(CACHE_DIR, name + ".cache")


def cache_get(key, max_age=3600):
    path = cache_path(key)
    if not os.path.exists(path):
        return None

    if time.time() - os.path.getmtime(path) > max_age:
        return None

    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except:
        return None


def cache_set(key, data):
    try:
        with open(cache_path(key), "w", encoding="utf-8") as f:
            f.write(data)
    except:
        pass


# ====================== LOADER REMOTO =====================================

def load_remote_list(url, use_cache=True):
    """
    Carrega JSON/XML/M3U com cache opcional.
    Fanarts, thumbs e URLs remotas são preservadas.
    """
    if use_cache:
        cached = cache_get(url)
        if cached:
            parsed = autodetect_list(cached)
            if parsed:
                return parsed

    content = http_get(url)
    if not content:
        notify("Falha ao acessar lista remota")
        return []

    items = autodetect_list(content)

    if use_cache and items:
        cache_set(url, content)

    return items


# ====================== UI / ADIÇÃO DE ITENS ==============================

def add_item(name, url, thumb=None, plot=None, fanart=None, folder=False):
    """
    Item clicável no Kodi:
    - mode=1 → reprodução
    - mode=2 → abrir submenu remoto
    """

    try:
        params = {
            "name": quote_plus(name),
            "url": quote_plus(url)
        }

        mode = 1 if not folder else 2
        param_str = "&".join(["%s=%s" % (k, v) for k, v in params.items()])
        final_url = "%s?mode=%d&%s" % (sys.argv[0], mode, param_str)

        li = xbmcgui.ListItem(label=name)

        art = {}
        if thumb:
            art["thumb"] = thumb
            art["icon"] = thumb
        if fanart:
            art["fanart"] = fanart

        if art:
            li.setArt(art)

        if plot:
            li.setInfo("video", {"title": name, "plot": plot})

        xbmcplugin.addDirectoryItem(HANDLE, final_url, li, isFolder=folder)

    except Exception as e:
        log("add_item erro: %s" % str(e), "ERROR")


# ====================== BUILD MENU REMOTO =================================

def build_remote_menu(url):
    """
    Lê uma lista remota (JSON/XML/M3U) e monta a interface com fanart, thumb, plot etc.
    """
    items = load_remote_list(url)

    if not items:
        notify("Lista remota vazia")
        return

    for it in items:
        title = it.get("title") or "Sem título"
        link = it.get("url") or ""
        thumb = it.get("thumb")
        plot = it.get("plot")
        fanart = it.get("fanart")

        # se for pasta: {"folder": true, "url": "https://.../submenu.json"}
        folder = bool(it.get("folder", False))

        add_item(
            name=title,
            url=link,
            thumb=thumb,
            plot=plot,
            fanart=fanart,
            folder=folder
        )
        
        # ====================== PLAYER ACTION =====================================

def action_play(name, url):
    """
    Reprodução direta de magnets/torrents/vídeos.
    """
    if not url:
        notify("URL vazia")
        return

    resolved = resolver(url)

    # Elementum
    if resolved.startswith("plugin://plugin.video.elementum"):
        xbmc.executebuiltin("RunPlugin(%s)" % resolved)
        return

    # Player nativo
    try:
        li = xbmcgui.ListItem(label=name)
        xbmc.Player().play(resolved, li)
    except Exception as e:
        log("action_play erro: %s" % str(e), "ERROR")
        notify("Falha ao reproduzir")


# ====================== ROUTER (MODE 1/2) =================================

def router(params):
    """
    mode=1 → play
    mode=2 → submenu remoto
    """
    mode = int(params.get("mode", 0))

    if mode == 1:
        # reproduzir
        name = unquote_plus(params.get("name", "Sem Nome"))
        url = unquote_plus(params.get("url", ""))
        action_play(name, url)

    elif mode == 2:
        # abrir lista remota
        remote = unquote_plus(params.get("url", ""))
        if not remote:
            notify("URL remota inválida")
            return
        build_remote_menu(remote)

    else:
        # modo desconhecido → menu principal
        build_main_menu()


# ====================== MENU PRINCIPAL ====================================

def build_main_menu():
    """
    Menu inicial do addon apontando para uma lista remota.
    """
    try:
        add_item(
            name="Abrir Menu Remoto",
            url=REMOTE_MENU_URL,
            thumb=None,
            plot="Carregar interface completa pela URL remota.",
            fanart=None,
            folder=True
        )

        add_item(
            name="Exemplo Magnet",
            url="magnet:?xt=urn:btih:EXAMPLE1234567890&dn=Example",
            thumb=None,
            plot="Teste de reprodução Elementum.",
            folder=False
        )

        add_item(
            name="Exemplo Torrent Direto",
            url="https://meu-servidor.com/arquivo.torrent",
            thumb=None,
            plot="Teste de execução torrent via Elementum.",
            folder=False
        )

    except Exception as e:
        log("Erro em build_main_menu: %s" % str(e), "ERROR")
        notify("Erro no menu principal")


# ====================== FINALIZAÇÃO DO DIRETÓRIO ===========================

def end_dir():
    try:
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
    except:
        pass


# ====================== MAIN / ENTRYPOINT =================================

def run():
    """
    Entrada principal do addon.
    """
    try:
        params = get_params()

        if not params:
            build_main_menu()
            end_dir()
            return

        router(params)
        end_dir()

    except Exception as e:
        log("run erro: %s\n%s" % (str(e), traceback.format_exc()), "ERROR")
        notify("Erro interno")


# ====================== EXECUÇÃO DIRETA ===================================

if __name__ == "__main__":
    run()